# Prodeco

### Ejecutar

```
python3 prodeco/prodeco.py
```